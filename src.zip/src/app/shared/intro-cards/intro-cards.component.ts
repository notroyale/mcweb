import { Component } from '@angular/core';

@Component({
  selector: 'app-intro-cards',
  standalone: true,
  imports: [],
  templateUrl: './intro-cards.component.html',
  styleUrl: './intro-cards.component.scss'
})
export class IntroCardsComponent {

}
