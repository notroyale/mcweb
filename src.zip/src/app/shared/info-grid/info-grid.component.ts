import { Component } from '@angular/core';

@Component({
  selector: 'app-info-grid',
  standalone: true,
  imports: [],
  templateUrl: './info-grid.component.html',
  styleUrl: './info-grid.component.scss'
})
export class InfoGridComponent {

}
