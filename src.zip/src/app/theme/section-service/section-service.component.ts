import { Component } from '@angular/core';

@Component({
  selector: 'app-section-service',
  standalone: true,
  imports: [],
  templateUrl: './section-service.component.html',
  styleUrl: './section-service.component.scss'
})
export class SectionServiceComponent {

}
