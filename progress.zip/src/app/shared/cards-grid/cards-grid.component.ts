import { Component } from '@angular/core';

@Component({
  selector: 'app-cards-grid',
  standalone: true,
  imports: [],
  templateUrl: './cards-grid.component.html',
  styleUrl: '../info-grid/info-grid.component.scss'
})
export class CardsGridComponent {

}
