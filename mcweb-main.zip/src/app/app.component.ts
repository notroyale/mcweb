import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Application } from '@splinetool/runtime';

const menu = document.querySelector(".menu-block");

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  ngOnInit(): void {

// const canvas:any = document.getElementById('canvas3d');
// const app = new Application(canvas);
// app.load('https://prod.spline.design/v8zRS0w-hl1JrHbW/scene.splinecode');

    this.loadScript()  }
  title = 'mcweb';

  toggleMenu() {
    menu?.classList.toggle("active");
    document.querySelector(".menu-overlay")?.classList.toggle("active");
  }
  private scriptLoaded = false;
 loadScript(): Promise<void> {
   if (!this.scriptLoaded) {
     return new Promise<void>((resolve, reject) => {
       const scriptElement = document.createElement('script');
       scriptElement.src = '../assets/js/vendors/menu.js';
       scriptElement.onload = () => {
         this.scriptLoaded = true;
         resolve();
       };
       scriptElement.onerror = (error) => reject(error);
       document.body.appendChild(scriptElement);
     });
   } else {
     return Promise.resolve();
   }
 }

 executeScriptFunction(): void {
  // Define functions here to interact with the loaded script
}
}


