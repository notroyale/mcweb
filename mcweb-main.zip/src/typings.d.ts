declare var variableName:any;
