import { Component } from '@angular/core';

@Component({
  selector: 'app-roadmap-section',
  standalone: true,
  imports: [],
  templateUrl: './roadmap-section.component.html',
  styleUrl: './roadmap-section.component.scss'
})
export class RoadmapSectionComponent {

}
