import { Component } from '@angular/core';

@Component({
  selector: 'app-tokenomics-section',
  standalone: true,
  imports: [],
  templateUrl: './tokenomics-section.component.html',
  styleUrl: './tokenomics-section.component.scss'
})
export class TokenomicsSectionComponent {

}
